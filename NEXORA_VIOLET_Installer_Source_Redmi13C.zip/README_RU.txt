NEXORA VIOLET — Android installer project
==========================================

Target tested by design assumptions from user-provided screenshot:
Redmi 13C / HyperOS 2.0.204.0 / Android 15.

What this app actually does:
- Provides a one-tap "Установить обои" action using Android WallpaperManager.
- Opens the Xiaomi Themes app if installed.
- Bundles 12 icon PNGs and SF Pro Text font files as app assets.

Important limitations:
- This is SOURCE CODE, not a compiled APK.
- Standard HyperOS launcher does not expose a universal public API for third-party apps
  to silently apply custom icon packs or system fonts.
- The app does not root, patch /system, install LSPosed, or change Control Center/status bar.
- It intentionally does not use Magisk because an unverified boot module could bootloop the device.

Build:
- Push this project to a GitHub repository.
- GitHub Actions workflow `.github/workflows/build.yml` builds a debug APK.
- Download artifact `NEXORA-VIOLET-APK` from Actions.
