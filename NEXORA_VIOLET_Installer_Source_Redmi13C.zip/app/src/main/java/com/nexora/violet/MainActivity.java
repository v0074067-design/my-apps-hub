package com.nexora.violet;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF100B1C);
        getWindow().setNavigationBarColor(0xFF08060D);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(36), dp(24), dp(24));
        page.setBackgroundColor(0xFF0B0812);
        page.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("NEXORA VIOLET");
        title.setTextColor(0xFFE9D9FF);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView subtitle = new TextView(this);
        subtitle.setText("ТВОЙ ФИОЛЕТОВЫЙ СТИЛЬ");
        subtitle.setTextColor(0xFFB99AEF);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(36)));

        TextView info = new TextView(this);
        info.setText("Один тап применяет обои. Иконки и шрифты подготовлены внутри набора — их применение зависит от возможностей темы и лаунчера HyperOS.");
        info.setTextColor(0xFFD4C9E2);
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(22), 0, dp(22));
        page.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button wallpaper = makeButton("УСТАНОВИТЬ ОБОИ");
        wallpaper.setOnClickListener(v -> applyWallpaper());
        page.addView(wallpaper, buttonParams());

        Button themes = makeButton("ОТКРЫТЬ ПРИЛОЖЕНИЕ «ТЕМЫ»");
        themes.setOnClickListener(v -> openThemes());
        page.addView(themes, buttonParams());

        Button about = makeButton("ЧТО ВХОДИТ В ОФОРМЛЕНИЕ");
        about.setOnClickListener(v -> Toast.makeText(this,
            "Обои 1080×2340, 12 PNG-иконок и два файла SF Pro Text. Иконки/шрифты не применяются автоматически стандартным лаунчером HyperOS.",
            Toast.LENGTH_LONG).show());
        page.addView(about, buttonParams());

        TextView footer = new TextView(this);
        footer.setText("REDMI 13C • HYPEROS 2 • ANDROID 15\\nБез модификации системных разделов");
        footer.setTextColor(0xFF82758F);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(28);
        page.addView(footer, fp);

        setContentView(page);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6336A8));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.topMargin = dp(12);
        return p;
    }

    private void applyWallpaper() {
        try (InputStream in = getAssets().open("wallpaper.jpg")) {
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            WallpaperManager.getInstance(this).setBitmap(bitmap);
            Toast.makeText(this, "Обои NEXORA VIOLET установлены", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось установить обои: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openThemes() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.android.thememanager");
        if (launch != null) startActivity(launch);
        else {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=Themes"))); }
            catch (Exception e) { Toast.makeText(this, "Открой приложение «Темы» вручную", Toast.LENGTH_LONG).show(); }
        }
    }
}
