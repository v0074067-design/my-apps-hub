package com.gametoolspro.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView screen = new TextView(this);
        screen.setText("");
        screen.setTextColor(Color.BLACK);
        screen.setBackgroundColor(Color.WHITE);
        screen.setGravity(Gravity.CENTER);
        setContentView(screen);
    }
}
